# Changelog
## 1.2.0
 - Added a Button to Force Stop Downloads
 - Added a Button to decide whether a Monster should hear the played audio or not
 - Added a Button to decide whether the current audio listening to should be looped or not
 - Added a Button to Mute or Unmute audio (Client only)
 - Added a Button to Fast-Forward and one for rewinding (10 seconds each click)
 - Added a Button to toggle a Visual Effect on the Cart
 - Configurable Keybind for opening the Boombox UI (only with the REPOConfig Mod)
 - Edited the position of the 'Close' Button and enlarged it
 - Replaced broken Discord Link in the Readme
Thanks to @philtec for Coding
## 1.1.1
Added GitHub link
## 1.1.0
 - Important fix for incorrect timeout error
 - Added support for more URL's than just youtube, see README for supported websites (probably more to come)
 - Known issue: cannot recover from some timeouts. working on a fix
## 1.0.3
Fixed youtube videos with special characters in the title not able to be played
## 1.0.2
Minor tweaks to the boombox UI, updated youtube url validator for less false negatives
## 1.0.1
Fixed code which I think prevented upload
## 1.0.0
Initial release!