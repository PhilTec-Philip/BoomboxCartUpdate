# Changelog
## 1.1.0
 - Important fix for incorrect timeout error
 - Added support for more URL's than just youtube, see README for supported websites (probably more to come)
 - Known issue: cannot recover from some timeouts. working on a fix
## 1.0.3
Fixed youtube videos with special characters in the title not able to be played
## 1.0.2
Minor tweaks to the boombox UI, updated youtube url validator for less false negatives
## 1.0.1
Fixed code which I think prevented upload
## 1.0.0
Initial release!